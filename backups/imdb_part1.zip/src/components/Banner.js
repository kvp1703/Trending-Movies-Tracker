import React from 'react';
import Image from '../resources/banner.png';

function Banner() {
  return <>
    <div className={`bg-[url(${Image})] h-[40vh] md:h-[60vh]
      bg-center bg-cover flex items-end justify-center`}>
      <div className="text-xl md: text-3xl  
        text-white p-4
        bg-gray-900 bg-opacity-70
        w-full flex justify-center " >
        Spider-Man : No Way Home</div>
    </div>
  </>
}

export default Banner;
