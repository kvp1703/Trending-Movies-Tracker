import React from 'react'

function Favourites() {
  return (
    <div>Favourites Component</div>
  )
}

export default Favourites